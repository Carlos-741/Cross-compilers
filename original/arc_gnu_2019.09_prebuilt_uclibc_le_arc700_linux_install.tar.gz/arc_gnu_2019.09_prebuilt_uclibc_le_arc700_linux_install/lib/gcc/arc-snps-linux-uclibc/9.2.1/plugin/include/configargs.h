/* Generated automatically. */
static const char configuration_arguments[] = "/SCRATCH/arcjenkins2/slaves/ru20-custom-arcgnu2/workspace/arcoss_verification/arc_gnu_toolchain_release/arc_gnu_toolchain_release/gcc/configure --target=arc-snps-linux-uclibc --with-cpu=arc700 --disable-multilib --with-pkgversion='ARCompact ISA Linux uClibc toolchain 2019.09' --with-bugurl=https://github.com/foss-for-synopsys-dwc-arc-processors/toolchain/issues --enable-fast-install=N/A --with-endian=little --disable-werror --enable-languages=c,c++ --prefix=/SCRATCH/arcjenkins2/slaves/ru20-custom-arcgnu2/workspace/arcoss_verification/arc_gnu_toolchain_release/arc_gnu_toolchain_release/toolchain/../release_output/arc_gnu_2019.09_prebuilt_uclibc_le_arc700_linux_install --enable-shared --without-newlib --disable-libgomp --with-gnu-as --with-gnu-ld --with-python=no --with-isl=no --with-sysroot=/SCRATCH/arcjenkins2/slaves/ru20-custom-arcgnu2/workspace/arcoss_verification/arc_gnu_toolchain_release/arc_gnu_toolchain_release/toolchain/../release_output/arc_gnu_2019.09_prebuilt_uclibc_le_arc700_linux_install/arc-snps-linux-uclibc/sysroot";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "arc700" } };
