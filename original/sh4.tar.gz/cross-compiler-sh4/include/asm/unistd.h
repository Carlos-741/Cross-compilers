# ifdef __SH5__
#  include <asm/unistd_64.h>
# else
#  include <asm/unistd_32.h>
# endif
