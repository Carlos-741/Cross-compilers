/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/opt/sparc64--glibc--stable-2018.11-1 --sysconfdir=/opt/sparc64--glibc--stable-2018.11-1/etc --enable-static --target=sparc64-buildroot-linux-gnu --with-sysroot=/opt/sparc64--glibc--stable-2018.11-1/sparc64-buildroot-linux-gnu/sysroot --disable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --with-gmp=/opt/sparc64--glibc--stable-2018.11-1 --with-mpc=/opt/sparc64--glibc--stable-2018.11-1 --with-mpfr=/opt/sparc64--glibc--stable-2018.11-1 --with-pkgversion='Buildroot 2018.08.1-00003-g576b333' --with-bugurl=http://bugs.buildroot.net/ --disable-libquadmath --disable-libsanitizer --enable-tls --disable-libmudflap --enable-threads --without-isl --without-cloog --disable-decimal-float --with-cpu=ultrasparc --enable-languages=c,c++ --with-build-time-tools=/opt/sparc64--glibc--stable-2018.11-1/sparc64-buildroot-linux-gnu/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "cpu", "ultrasparc" } };
