/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/opt/sh-sh4--glibc--stable-2018.11-1 --sysconfdir=/opt/sh-sh4--glibc--stable-2018.11-1/etc --enable-static --target=sh4-buildroot-linux-gnu --with-sysroot=/opt/sh-sh4--glibc--stable-2018.11-1/sh4-buildroot-linux-gnu/sysroot --disable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --with-gmp=/opt/sh-sh4--glibc--stable-2018.11-1 --with-mpc=/opt/sh-sh4--glibc--stable-2018.11-1 --with-mpfr=/opt/sh-sh4--glibc--stable-2018.11-1 --with-pkgversion='Buildroot 2018.08.1-00003-g576b333' --with-bugurl=http://bugs.buildroot.net/ --disable-libquadmath --enable-tls --disable-libmudflap --enable-threads --without-isl --without-cloog --disable-decimal-float --enable-languages=c,c++ --with-build-time-tools=/opt/sh-sh4--glibc--stable-2018.11-1/sh4-buildroot-linux-gnu/bin --with-multilib-list=m4,m4a,m4-nofpu,m4a-nofpu --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
