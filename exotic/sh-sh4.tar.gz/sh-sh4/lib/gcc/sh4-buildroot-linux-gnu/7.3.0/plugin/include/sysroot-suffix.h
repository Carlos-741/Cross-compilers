#undef SYSROOT_SUFFIX_SPEC
#define SYSROOT_SUFFIX_SPEC "" \
"%{m4:/m4;" \
"m4a:/m4a;" \
"m4-nofpu:/m4-nofpu;" \
"m4a-nofpu:/m4a-nofpu;" \
":}"
