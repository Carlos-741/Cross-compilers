/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/opt/mips64-n32--glibc--stable-2018.11-1 --sysconfdir=/opt/mips64-n32--glibc--stable-2018.11-1/etc --enable-static --target=mips64-buildroot-linux-gnu --with-sysroot=/opt/mips64-n32--glibc--stable-2018.11-1/mips64-buildroot-linux-gnu/sysroot --disable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --with-gmp=/opt/mips64-n32--glibc--stable-2018.11-1 --with-mpc=/opt/mips64-n32--glibc--stable-2018.11-1 --with-mpfr=/opt/mips64-n32--glibc--stable-2018.11-1 --with-pkgversion='Buildroot 2018.08.1-00003-g576b333' --with-bugurl=http://bugs.buildroot.net/ --disable-libquadmath --enable-tls --disable-libmudflap --enable-threads --without-isl --without-cloog --disable-decimal-float --with-arch=mips64 --with-abi=n32 --with-nan=legacy --enable-languages=c,c++ --with-build-time-tools=/opt/mips64-n32--glibc--stable-2018.11-1/mips64-buildroot-linux-gnu/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "n32" }, { "arch", "mips64" }, { "nan", "legacy" }, { "llsc", "llsc" } };
