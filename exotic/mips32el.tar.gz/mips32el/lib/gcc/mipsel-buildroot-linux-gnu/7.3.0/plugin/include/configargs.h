/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/opt/mips32el--glibc--stable-2018.11-1 --sysconfdir=/opt/mips32el--glibc--stable-2018.11-1/etc --enable-static --target=mipsel-buildroot-linux-gnu --with-sysroot=/opt/mips32el--glibc--stable-2018.11-1/mipsel-buildroot-linux-gnu/sysroot --disable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --with-gmp=/opt/mips32el--glibc--stable-2018.11-1 --with-mpc=/opt/mips32el--glibc--stable-2018.11-1 --with-mpfr=/opt/mips32el--glibc--stable-2018.11-1 --with-pkgversion='Buildroot 2018.08.1-00003-g576b333' --with-bugurl=http://bugs.buildroot.net/ --disable-libquadmath --enable-tls --disable-libmudflap --enable-threads --without-isl --without-cloog --disable-decimal-float --with-arch=mips32 --with-abi=32 --with-nan=legacy --with-fp-32=xx --enable-languages=c,c++ --with-build-time-tools=/opt/mips32el--glibc--stable-2018.11-1/mipsel-buildroot-linux-gnu/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "32" }, { "arch", "mips32" }, { "nan", "legacy" }, { "fp_32", "xx" }, { "llsc", "llsc" } };
