/* Generated automatically. */
static const char configuration_arguments[] = "./configure --prefix=/tmp/mips32r6el--glibc--stable/usr --sysconfdir=/tmp/mips32r6el--glibc--stable/etc --enable-static --target=mipsel-buildroot-linux-gnu --with-sysroot=/tmp/mips32r6el--glibc--stable/usr/mipsel-buildroot-linux-gnu/sysroot --disable-__cxa_atexit --with-gnu-ld --disable-libssp --disable-multilib --with-gmp=/tmp/mips32r6el--glibc--stable/usr --with-mpc=/tmp/mips32r6el--glibc--stable/usr --with-mpfr=/tmp/mips32r6el--glibc--stable/usr --with-pkgversion='Buildroot 2017.05' --with-bugurl=http://bugs.buildroot.net/ --disable-libquadmath --enable-tls --disable-libmudflap --enable-threads --without-isl --without-cloog --disable-decimal-float --with-arch=mips32r6 --with-abi=32 --enable-languages=c,c++ --with-build-time-tools=/tmp/mips32r6el--glibc--stable/usr/mipsel-buildroot-linux-gnu/bin --enable-shared --disable-libgomp";
static const char thread_model[] = "posix";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { "abi", "32" }, { "arch", "mips32r6" }, { "llsc", "llsc" } };
